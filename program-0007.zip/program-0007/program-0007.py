dict={'首页': '736355', '新闻详情页': '898165'}
print(max(dict, key=dict.get))