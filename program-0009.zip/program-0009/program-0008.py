import tkinter as tk
from bs4 import BeautifulSoup
from tkinter import filedialog
import re

def get_file_path():
    windows = tk.Tk()
    windows.withdraw()

    file_path = filedialog.askopenfilename()
    print(file_path)
    check_file_path(file_path)
    return file_path

def check_file_path(file_path):
    pattern = ".html$"
    print(re.findall(pattern, file_path))
    if re.findall(pattern, file_path) is not None:
        output_file_content(file_path)
        return file_path
    
def output_file_content(file_path):
    file = open(file_path, "r")
    html_text = file.read()

    html_soup = BeautifulSoup(html_text, "html.parser")
    for item in html_soup.find_all("a"):
        print("链接为：", item.get("href"))
    print("标题为：", html_soup.title)

if __name__ == '__main__':
    get_file_path()
