import csv, re
import tkinter as tk
from tkinter import filedialog
import xlrd, zipfile

class StudentInfo:
    def __init__(self, number, name, sex, age):
        self.number = number
        self.name = name
        self.sex = sex
        self.age = age

# 用正则表达式检查获取到的文件格式
def check_file_format(file_path):
    print(file_path)
    pattern = '\.\S*$'
    result = re.findall(pattern, file_path)

    if result[0] == ".csv":             
        use_csv_create_joseph(file_path)    #如果是csv格式则实现跳转
    elif result[0] == ".xlsx":
        use_xlsx_create_joseph(file_path)
    elif result[0] == ".zip":
        use_zip_create_joseph(file_path)

# 用csv格式的文件创建约瑟夫环
def use_csv_create_joseph(file_csv_path):
    file = open(file_csv_path, 'r')
    student_data = csv.reader(file)
    student_data = list(student_data)

    student_object_list = []
    for element in student_data:
        student_sub_data = re.findall('\S* ', element[0])
        student_object = StudentInfo(
            student_sub_data[0], student_sub_data[1], 
            student_sub_data[2], student_sub_data[3])
        student_object_list.append(student_object)
        #print(student_object.__dict__)

    create_joseph_ring(student_object_list, len(student_object_list))

    return student_object.__dict__

# 用excel格式的文件数据创建约瑟夫环
def use_xlsx_create_joseph(file_xlsx_path):
    data = xlrd.open_workbook(file_xlsx_path)
    sheet = data.sheet_by_name('Sheet1')

    student_object_list = []
    for num in range(sheet.nrows):
        student_data = sheet.row_values(num)
        student_object = StudentInfo(
            student_data[0], student_data[1], 
            student_data[2], student_data[3])

        student_object_list.append(student_object)
    create_joseph_ring(student_object_list, len(student_object_list))

    return student_object_list

# 用压缩文件的格式创建约瑟夫环
def use_zip_create_joseph(file_zip_path):
    file_zip = zipfile.ZipFile(file_zip_path, 'r')
    file_zip = file_zip.read(file_zip.namelist()[0]).decode('gbk')

    student_object_list = []
    for line in file_zip.split("$"):
        student_data = re.findall('\S* ', line)
        student_object = StudentInfo(
            student_data[0], student_data[1], 
            student_data[2], student_data[3])
        student_object_list.append(student_object)
    
    create_joseph_ring(student_object_list, len(student_object_list))

    return student_object_list
    
# 打开对话框，获取文件路径   
def get_file_path():
    windows = tk.Tk()
    windows.withdraw()

    file_path = filedialog.askopenfilename()
    check_file_format(file_path)

    return file_path

# 解决约瑟夫环问题
def create_joseph_ring(
        joseph_student_list, joseph_student_all, 
        joseph_student_delete=3):
    list_finally = []
    num_temporary = 0

    print("学生总量为：", joseph_student_all)
    while True:
        if len(joseph_student_list) > 1:
            num_temporary = ((joseph_student_delete 
                              - 1 
                              + num_temporary) 
                              % len(joseph_student_list))
            print("被淘汰的学生信息：" + str(joseph_student_list[num_temporary].__dict__))
            list_finally.append(joseph_student_list[num_temporary])
            del joseph_student_list[num_temporary]
        else:
            break;
    print("最后留下的学生信息：" + str(joseph_student_list[0].__dict__))

    return joseph_student_list[0]

# 将约瑟夫环作为容器，随后遍历容器内容
def create_joseph_ring_container(joseph_student_all, 
        joseph_student_delete):
    joseph_container = []
    count = 0
    for num in range(joseph_student_all):
        joseph_container.append('*')
   
    num = 0
    while(count < joseph_student_all):
        for i in range(joseph_student_all):
            if joseph_container[i] == "*":
                print(num)
                num += 1
                #print(num)
            if num == joseph_student_delete:
                joseph_container[i] = count
                count += 1
                num = 0
        
    print("遍历约瑟夫环容器结果为：" + str(joseph_container))

if __name__ == '__main__':
    get_file_path()
    #create_joseph_ring_container(9,2)
